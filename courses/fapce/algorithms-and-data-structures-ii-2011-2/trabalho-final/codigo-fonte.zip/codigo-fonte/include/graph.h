#ifndef GRAPH_H
#define GRAPH_H

#include <stdio.h>
#include <stdlib.h>

#include <utils.h>

typedef struct neighbor {
  int v; /* número do vértice */
  int w; /* peso da aresta */
  struct neighbor *next;
} Neighbor;

typedef int**     Adjacency_matrix;
typedef Neighbor* Adjacency_list;

typedef struct graph {
  bool directed;
  int n, m;
  Adjacency_list *adj;
} Graph;

Graph *create_graph(int n, bool directed);

/* Insere aresta no início da vizinhança */
void add_edge(Graph *G, int u, int v, int w);

void graph_writer(Graph *G, FILE *os);

void graphviz_graph_writer(Graph *G, FILE *os);

#endif /* GRAPH_H */
