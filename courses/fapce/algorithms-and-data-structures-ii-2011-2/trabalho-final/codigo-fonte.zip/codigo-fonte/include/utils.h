#ifndef UTILS_H
#define UTILS_H

#define NIL -1

typedef enum {
  FALSE = 0,
  TRUE
} bool;

enum color {
  WHITE,
  GRAY,
  BLACK
};

#endif /* UTILS_H */
