#include <stdio.h>
#include <time.h>

#include <graph.h>

int best_city_for_hospital_constant(Graph *G)
{
  return 0;
}

int best_city_for_hospital_weighted(Graph *G)
{
  return 0;
}

int main(int argc, char *argv[])
{
  int cid1, cid2;
  clock_t t0, t1, start, end;
  double time1, time2, totaltime;
  char *city[] = {
		  "Campos Sales",
		  "Fortaleza",
		  "Juazeiro do Norte",
		  "Quixeramobim",
		  "Quixadá",
		  "Sobral"};
  Graph *G;

  start = clock();

  G = create_graph(6, FALSE);
  add_edge(G, 3, 2, 1);
  add_edge(G, 2, 0, 1);
  add_edge(G, 3, 0, 1);
  add_edge(G, 1, 5, 1);
  add_edge(G, 0, 1, 1);
  add_edge(G, 4, 0, 1);
  add_edge(G, 5, 4, 1);

  t0 = clock();
  cid1 = best_city_for_hospital_constant(G);
  t1 = clock();
  time1 = ((double) (t1 - t0)) / CLOCKS_PER_SEC;

  t0 = clock();
  cid2 = best_city_for_hospital_weighted(G);
  t1 = clock();
  time2 = ((double) (t1 - t0)) / CLOCKS_PER_SEC;

  end = clock();
  totaltime = ((double) (end - start)) / CLOCKS_PER_SEC;

  printf(" Caso | Cidade Escolhida  \n");
  printf("------|-------------------\n");
  printf("  %02d  | %s\n", 1, city[cid1]);
  printf("  %02d  | %s\n", 2, city[cid2]);

  printf("\n");
  printf(" Tempo de CPU (sec)\n");
  printf("--------------------\n");
  printf("  Caso 01: %f\n", time1);
  printf("  Caso 02: %f\n", time2);
  printf("  Total  : %f\n", totaltime);

  return 0;
}
