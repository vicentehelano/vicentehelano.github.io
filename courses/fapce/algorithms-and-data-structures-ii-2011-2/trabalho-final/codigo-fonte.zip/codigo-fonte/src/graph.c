#include <stdlib.h>

#include <graph.h>

Graph *create_graph(int n, bool directed)
{
  int i;
  Graph *G = (Graph *) malloc(sizeof(Graph));
  G->n = n;
  G->m = 0;
  G->directed = directed;
  G->adj = (Adjacency_list *) malloc(n * sizeof(Adjacency_list));
  for (i = 0; i < n; i++) {
    G->adj[i] = NULL;
  }
  return G;
}

/* Função auxiliar */
void __add_edge(Graph *G, int u, int v, int w)
{
   Neighbor *p = (Neighbor *) malloc(sizeof(Neighbor));
   p->v = v;
   p->w = w;
   p->next = G->adj[u];
   G->adj[u] = p;
}

/* Insere aresta no início da vizinhança */
void add_edge(Graph *G, int u, int v, int w)
{
  /* não permitimos laços */
  if (u == v) return;

  __add_edge(G, u, v, w);
  if (!G->directed) {
    __add_edge(G, v, u, w);
  }
  G->m++;
}

void graph_writer(Graph *G, FILE *os)
{
  int u;
  Neighbor *p;

  printf("%d\n", G->n);
  for (u = 0; u < G->n; u++) {
    for (p = G->adj[u]; p != NULL; p = p->next) {
      fprintf(os, "%d ", p->v);
    }
    fprintf(os, "\n");
  }
}

void graphviz_graph_writer(Graph *G, FILE *os)
{
  /* TODO */
}
