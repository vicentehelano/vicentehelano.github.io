#ifndef POINT_2_H
#define POINT_2_H

#include "Vector_2.h"

class Point_2
{
public:
  // Construtores
  Point_2();
  Point_2(double x, double y);
  Point_2(const Point_2& p);

  // Acesso
  double x() const;
  double y() const;

  // Operadores
  Point_2& operator=(const Point_2& p);
  Point_2& operator+=(const Vector_2& v);
  Point_2 operator+(const Vector_2& v);
  Vector_2 operator-(const Point_2& p);

private:
  double _x, _y;
};

#endif // POINT_2_H
