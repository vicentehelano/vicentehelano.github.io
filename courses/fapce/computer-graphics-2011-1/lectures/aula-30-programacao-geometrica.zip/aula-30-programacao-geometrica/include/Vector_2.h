#ifndef VECTOR_2_H
#define VECTOR_2_H

class Vector_2
{
public:
  // Construtores
  Vector_2();
  Vector_2(double x, double y);
  Vector_2(const Vector_2& v);

  // Acesso
  double x() const;
  double y() const;

  // Operadores
  Vector_2& operator=(const Vector_2& v);

private:
  double _x, _y;
};

#endif // VECTOR_2_H
