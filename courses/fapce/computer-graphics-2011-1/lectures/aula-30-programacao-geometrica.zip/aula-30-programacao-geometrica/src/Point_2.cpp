#include "Point_2.h"

// Construtores
Point_2::Point_2() : _x(0.0), _y(0.0)
{ }

Point_2::Point_2(double x = 0.0, double y = 0.0) : _x(x), _y(y)
{ }

Point_2::Point_2(const Point_2& p) : _x(p.x()), _y(p.y())
{ }

// Acesso
double
Point_2::x() const
{
  return _x;
}

double
Point_2::y() const
{
  return _y;
}

// Operadores
Point_2&
Point_2::operator=(const Point_2& p)
{
  _x = p.x();
  _y = p.y();
  return *this;
}

Point_2&
Point_2::operator+=(const Vector_2& v)
{
  _x += v.x();
  _y += v.y();
  return *this;
}

Point_2
Point_2::operator+(const Vector_2& v)
{
  return Point_2(_x + v.x(), _y + v.y());
}

Vector_2
Point_2::operator-(const Point_2& p)
{
  return Vector_2(_x - p.x(), _y - p.y());
}
