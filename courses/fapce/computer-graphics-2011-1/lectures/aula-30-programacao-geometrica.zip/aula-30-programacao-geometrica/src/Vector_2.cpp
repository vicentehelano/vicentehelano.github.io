#include "Vector_2.h"

// Construtores
Vector_2::Vector_2()
  : _x(0.0), _y(0.0) { }

Vector_2::Vector_2(double x = 0.0, double y = 0.0)
  : _x(x), _y(y) { }

Vector_2::Vector_2(const Vector_2& v)
  : _x(v.x()), _y(v.y()) { }

// Acesso
double
Vector_2::x() const
{
  return _x;
}

double
Vector_2::y() const
{
  return _y;
}

// Operadores
Vector_2&
Vector_2::operator=(const Vector_2& v)
{
  _x = v.x();
  _y = v.y();
  return *this;
}
