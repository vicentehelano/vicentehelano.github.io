#include <cstdlib>
#include <iostream>
#include <vector>
#include <cmath>

#include <GL/glut.h>
#include <GL/glu.h>
#include <GL/gl.h>

#include <Point_2.h>
#include <Vector_2.h>

// Pol�gonos s�o representados como um vetor de pontos
typedef std::vector<Point_2> Polygon_2;

Polygon_2 polygon;
double view_w, view_h, pan_x = 0.0, pan_y = 0.0, zoom = 1.0;
double world_w, world_h;

void ajusta_aspecto()
{
  glMatrixMode(GL_PROJECTION);
  glLoadIdentity();

  if( view_w <= view_h ) {
    world_w = 2.0 * zoom;
    world_h = 2.0 * zoom * (GLfloat) view_h / (GLfloat) view_w;
                
    gluOrtho2D(-1.0 * zoom + pan_x,
                1.0 * zoom + pan_x,
               -1.0 * zoom * (GLfloat) view_h / (GLfloat) view_w + pan_y,
                1.0 * zoom * (GLfloat) view_h / (GLfloat) view_w + pan_y);
  } else {
    world_w = 2.0 * zoom * (GLfloat) view_w / (GLfloat) view_h;
    world_h = 2.0 * zoom;

    gluOrtho2D(-1.0 * zoom * (GLfloat) view_w / (GLfloat) view_h + pan_x,
                1.0 * zoom * (GLfloat) view_w / (GLfloat) view_h + pan_x,
               -1.0 * zoom + pan_y,
                1.0 * zoom + pan_y);
  }

  glMatrixMode(GL_MODELVIEW);
}

void processa_teclas_normais(unsigned char key, int x, int y)
{
  std::cerr << "aviso: tecla normal pressionada: " << key << std::endl;

  switch (key) {
    case '+':
      std::cerr << "aviso: zoom in.\n";
      zoom -= 0.1;
      ajusta_aspecto();
      break;
    case '-':
      std::cerr << "aviso: zoom in.\n";
      zoom += 0.1;
      ajusta_aspecto();
      break;
    case 'o':
      std::cerr << "aviso: zoom in.\n";
      zoom = 1.0;
      pan_x = pan_y = 0.0;
      ajusta_aspecto();
      break;
    case 27:
      std::cerr << "aviso: saindo do programa.\n";
      std::exit(0);
      break;
    default:
      break;
  }
  glutPostRedisplay();
}

void processa_teclas_especiais(int key, int x, int y)
{
  switch (key) {
    case GLUT_KEY_UP:
      std::cerr << "Transladando a tela para cima.\n";
      pan_y -= 0.1;
      ajusta_aspecto();
      break;
    case GLUT_KEY_DOWN:
      std::cerr << "Transladando a tela para baixo.\n";
      pan_y += 0.1;
      ajusta_aspecto();
      break;
    case GLUT_KEY_RIGHT:
      std::cerr << "Transladando a tela para a direita.\n";
      pan_x -= 0.1;
      ajusta_aspecto();
      break;
    case GLUT_KEY_LEFT:
      std::cerr << "Transladando a tela para a esquerda.\n";
      pan_x += 0.1;
      ajusta_aspecto();
      break;
    default:
      break;
  }
  glutPostRedisplay();
}

void processa_mouse(int button, int state, int x, int y)
{
  if (button == GLUT_LEFT_BUTTON)
    if (state == GLUT_DOWN) {
      std::cerr << "Botao esquerdo do mouse pressionado\n";
      double lambda_x = world_w / view_w;
      double lambda_y = world_h / view_h;
      double px = lambda_x * (x - view_w/2.0);
      double py = lambda_y * -1.0 * (y - view_h/2.0);
      std::cerr << "  Coordenadas de visor: " << x << ", " << y << std::endl;
      std::cerr << "  Coordenadas de cena: " << px << ", " << py << std::endl;
    }
  glutPostRedisplay();
}

void ajusta(int w, int h)
{
  // Guarda as dimens�es do visor para corrigir o aspecto da janela do universo.
  view_w = w;
  view_h = h;

  glViewport(0, 0, w, h);
  ajusta_aspecto();

  glutPostRedisplay();
}

void desenha()
{
  glClearColor(0., 0., 0., 1.0);
  glClear(GL_COLOR_BUFFER_BIT);
  glColor3f(1.0, 0.0, 0.0);

  glColor3f(0.0, 0.0, 1.0);
  glBegin(GL_POLYGON);
    for (size_t i = 0; i < polygon.size(); ++i) {
      glVertex2f(polygon[i].x(), polygon[i].y());
    }
  glEnd();

  glColor3f(1.0, 0.0, 0.0);
  glPointSize(10);
  glBegin(GL_POINTS);
    for (size_t i = 0; i < polygon.size(); ++i) {
      glVertex2f(polygon[i].x(), polygon[i].y());
    }
  glEnd();

  glutSwapBuffers();
}

void constroi_poligono()
{
  int n = 5;
  double r = 0.5;
  double t = r/n;

  double x = 0.0;
  while (x <= r) {
    double y = std::sqrt(r*r - x*x);
    polygon.push_back(Point_2(x, y));
    x += t;
  }
  polygon.push_back(Point_2(0, 0));
}

int main(int argc, char* argv[])
{
  glutInit(&argc, argv);
  glutInitDisplayMode(GLUT_DOUBLE | GLUT_RGBA);
  glutInitWindowSize(400, 400);
  glutInitWindowPosition(0, 0);
  glutCreateWindow("SI040: Computa��o Gr�fica - Lista 2");
  glutDisplayFunc(desenha);
  glutReshapeFunc(ajusta);
  glutKeyboardFunc(processa_teclas_normais);
  glutSpecialFunc(processa_teclas_especiais);
  glutMouseFunc(processa_mouse);

  constroi_poligono();

  glutMainLoop();

  return 0;
}
