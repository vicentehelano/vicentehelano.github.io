#ifndef POINT_3_H
#define POINT_3_H

#include "Vector_3.h"

class Point_3
{
public:
  // Construtores
  Point_3();
  Point_3(double x, double y, double z);
  Point_3(const Point_3& p);

  // Acesso
  double x() const;
  double y() const;
  double z() const;

  // Operadores
  Point_3& operator=(const Point_3& p);
  Point_3& operator+=(const Vector_3& v);
  Point_3 operator+(const Vector_3& v);
  Vector_3 operator-(const Point_3& p);

private:
  double _x, _y, _z;
};

#endif // POINT_3_H
