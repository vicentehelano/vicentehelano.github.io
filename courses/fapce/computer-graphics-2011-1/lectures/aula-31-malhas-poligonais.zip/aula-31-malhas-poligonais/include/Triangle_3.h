#ifndef TRIANGLE_3_H
#define TRIANGLE_3_H

#include "Point_3.h"

class Triangle_3
{
public:
  // Construtores
  Triangle_3();
  Triangle_3(Point_3& p1, Point_3& p2, Point_3& p3);
  Triangle_3(const Triangle_3& p);

  Point_3& vertex(const int i);

private:
  Point_3 _vertex[3];
};

#endif // TRIANGLE_3_H
