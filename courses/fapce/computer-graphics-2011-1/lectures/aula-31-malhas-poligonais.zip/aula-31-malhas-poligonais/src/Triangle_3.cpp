#include "Triangle_3.h"

// Construtores
Triangle_3::Triangle_3()
{
  _vertex[0] = Point_3();
  _vertex[1] = Point_3();
  _vertex[2] = Point_3();
}

Triangle_3::Triangle_3(Point_3& p1, Point_3& p2, Point_3& p3)
{
  _vertex[0] = p1;
  _vertex[1] = p2;
  _vertex[2] = p3;
}

Point_3&
Triangle_3::vertex(const int i)
{
  return _vertex[i];
}
