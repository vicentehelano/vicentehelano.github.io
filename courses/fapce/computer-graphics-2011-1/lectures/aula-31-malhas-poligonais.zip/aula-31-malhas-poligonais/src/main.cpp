#include <vector>
#include <iostream>

#include <Vector_3.h>
#include <Point_3.h>
#include <Triangle_3.h>

#include <GL/glut.h>

void iluminacao(void) 
{
  glClearColor (0.0, 0.0, 0.0, 0.0);
  glShadeModel (GL_FLAT);

  GLfloat light_position[] = { 1.0, 1.0, 1.0, 0.0 };
  glLightfv(GL_LIGHT0, GL_POSITION, light_position);
  glEnable(GL_LIGHTING);
  glEnable(GL_LIGHT0);

  glEnable(GL_DEPTH_TEST);

  glEnable(GL_CULL_FACE);
	glCullFace(GL_BACK);
}

void esfera()
{
  static GLfloat mat_ambient[] = { 0.2, 0.2, 0.2, 1.0 };
  static GLfloat mat_diffuse[] = { 1.0, 0.0, 0.0, 1.0 };
  static GLfloat mat_specular[] = { 1.0, 1.0, 1.0, 1.0 };
  static GLfloat mat_shininess[] = { 50.0 };

  glMaterialfv(GL_FRONT, GL_AMBIENT, mat_ambient);
  glMaterialfv(GL_FRONT, GL_DIFFUSE, mat_diffuse);
  glMaterialfv(GL_FRONT, GL_SPECULAR, mat_specular);
  glMaterialfv(GL_FRONT, GL_SHININESS, mat_shininess);

  glutSolidSphere(0.5, 20, 16);
}

void desenha(void)
{
  glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
  esfera();
  glutSwapBuffers();
}

void ajusta(int w, int h)
{
  glViewport (0, 0, (GLsizei) w, (GLsizei) h);

  glMatrixMode (GL_PROJECTION);
  glLoadIdentity();
  gluPerspective(50.0, // campo de visão
                 (GLfloat)w/(GLfloat)h, // razão de aspecto
                 1.0, // plano de recorte próximo
                 10.0); // plano de recorte distante

  glMatrixMode(GL_MODELVIEW);
  glLoadIdentity();
  gluLookAt(0.0, 0.0, 2.0, // posição da câmera
            0.0, 0.0, 0.0, // centro do plano de projeção
            0.0, 1.0, 0.0); // vetor que indica a direção do topo da câmera
}

void teclado(unsigned char key, int x, int y)
{
  switch (key) {
    case 27:
      exit(0);
      break;
  }
}

int main(int argc, char** argv)
{
  glutInit(&argc, argv);
  glutInitDisplayMode (GLUT_DOUBLE | GLUT_RGBA | GLUT_DEPTH);
  glutInitWindowSize (500, 500); 
  glutInitWindowPosition (100, 100);
  glutCreateWindow("SI041: Computação Gráfica - Lista 2");
  iluminacao();
  glutDisplayFunc(desenha); 
  glutReshapeFunc(ajusta);
  glutKeyboardFunc(teclado);
  glutMainLoop();
  return 0;
}
