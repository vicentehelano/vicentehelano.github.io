#ifndef FACE_3_H
#define FACE_3_H

class Face_3
{
public:
  // Construtores
  Face_3();
  Face_3(int v0, int v1, int v2);
  Face_3(int v0, int v1, int v2,
         int n0, int n1, int n2);

  int vertex(const int i);
  int neighbor(const int i);

private:
  int _vertex[3];
  int _neighbor[3];
};

#endif // FACE_3_H
