#ifndef VECTOR_3_H
#define VECTOR_3_H

class Vector_3
{
public:
  // Construtores
  Vector_3();
  Vector_3(double x, double y, double z);
  Vector_3(const Vector_3& v);

  // Acesso
  double x() const;
  double y() const;
  double z() const;

  // Operadores
  Vector_3& operator=(const Vector_3& v);

private:
  double _x, _y, _z;
};

#endif // VECTOR_3_H
