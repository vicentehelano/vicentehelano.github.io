#ifndef VERTEX_3_H
#define VERTEX_3_H

#include "Point_3.h"

class Vertex_3
{
public:
  // Construtores
  Vertex_3();
  Vertex_3(const Point_3& p);
  Vertex_3(const Vertex_3& v);

  // Acesso
  Point_3& point();
  const Point_3& point() const;

private:
  Point_3 _point;
};

#endif // VERTEX_3_H
