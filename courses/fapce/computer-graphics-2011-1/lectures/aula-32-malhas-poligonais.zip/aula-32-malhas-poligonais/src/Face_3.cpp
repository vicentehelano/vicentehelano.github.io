#include "Face_3.h"

// Construtores
Face_3::Face_3()
{ }

Face_3::Face_3(int v0, int v1, int v2)
{
  _vertex[0] = v0;
  _vertex[1] = v1;
  _vertex[2] = v2;
}

Face_3::Face_3(int v0, int v1, int v2,
               int n0, int n1, int n2)
{
  _vertex[0] = v0;
  _vertex[1] = v1;
  _vertex[2] = v2;

  _neighbor[0] = n0;
  _neighbor[1] = n1;
  _neighbor[2] = n2;
}

int
Face_3::vertex(const int i)
{
  return _vertex[i];
}

int
Face_3::neighbor(const int i)
{
  return _neighbor[i];
}

