#include "Vector_3.h"

// Construtores
Vector_3::Vector_3()
  : _x(0.0), _y(0.0), _z(0.0) { }

Vector_3::Vector_3(double x = 0.0, double y = 0.0, double z = 0.0)
  : _x(x), _y(y), _z(z) { }

Vector_3::Vector_3(const Vector_3& v)
  : _x(v.x()), _y(v.y()), _z(v.z()) { }

// Acesso
double
Vector_3::x() const
{
  return _x;
}

double
Vector_3::y() const
{
  return _y;
}

double
Vector_3::z() const
{
  return _z;
}

// Operadores
Vector_3&
Vector_3::operator=(const Vector_3& v)
{
  _x = v.x();
  _y = v.y();
  _z = v.z();
  return *this;
}
