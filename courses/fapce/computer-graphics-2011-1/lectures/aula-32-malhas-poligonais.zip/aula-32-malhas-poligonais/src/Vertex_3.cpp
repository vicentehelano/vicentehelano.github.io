#include "Vertex_3.h"

// Construtores
Vertex_3::Vertex_3() : _point()
{ }

Vertex_3::Vertex_3(const Point_3& p) : _point(p)
{ }

Vertex_3::Vertex_3(const Vertex_3& v) : _point(v.point())
{ }

// Acesso
Point_3&
Vertex_3::point()
{
  return _point;
}

const Point_3&
Vertex_3::point() const
{
  return this->_point;
}
