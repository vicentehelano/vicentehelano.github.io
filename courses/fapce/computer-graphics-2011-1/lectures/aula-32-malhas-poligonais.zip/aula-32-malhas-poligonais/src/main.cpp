#include <vector>
#include <iostream>
#include <fstream>

#include <Vector_3.h>
#include <Point_3.h>
#include <Vertex_3.h>
#include <Face_3.h>

#include <GL/glut.h>

std::vector<Vertex_3> vertices;
std::vector<Face_3> faces;

void configure_iluminacao(void) 
{
  glClearColor (0.0, 0.0, 0.0, 0.0);
  glShadeModel (GL_FLAT);

  GLfloat light_position[] = { 1.0, 1.0, 1.0, 0.0 };
  glLightfv(GL_LIGHT0, GL_POSITION, light_position);
  glEnable(GL_LIGHTING);
  glEnable(GL_LIGHT0);

  glEnable(GL_DEPTH_TEST);

  glEnable(GL_CULL_FACE);
	glCullFace(GL_BACK);
}

void desenha_malha()
{
  static GLfloat mat_ambient[] = { 0.2, 0.2, 0.2, 1.0 };
  static GLfloat mat_diffuse[] = { 1.0, 0.0, 0.0, 1.0 };
  static GLfloat mat_specular[] = { 1.0, 1.0, 1.0, 1.0 };
  static GLfloat mat_shininess[] = { 50.0 };

  glMaterialfv(GL_FRONT, GL_AMBIENT, mat_ambient);
  glMaterialfv(GL_FRONT, GL_DIFFUSE, mat_diffuse);
  glMaterialfv(GL_FRONT, GL_SPECULAR, mat_specular);
  glMaterialfv(GL_FRONT, GL_SHININESS, mat_shininess);

  Point_3 p0, p1, p2;
  int v0, v1, v2;

  glBegin(GL_TRIANGLES);
  for (size_t i = 0; i < faces.size(); ++i) {
    v0 = faces[i].vertex(0);
    v1 = faces[i].vertex(1);
    v2 = faces[i].vertex(2);

    p0 = vertices[v0].point();
    p1 = vertices[v1].point();
    p2 = vertices[v2].point();

    glVertex3f(p0.x(), p0.y(), p0.z());
    glVertex3f(p1.x(), p1.y(), p1.z());
    glVertex3f(p2.x(), p2.y(), p2.z());
  }
  glEnd();
}

void desenha(void)
{
  glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
  desenha_malha();
  glutSwapBuffers();
}

void ajusta(int w, int h)
{
  glViewport (0, 0, (GLsizei) w, (GLsizei) h);

  glMatrixMode (GL_PROJECTION);
  glLoadIdentity();
  gluPerspective(60.0, // campo de visão
                 (GLfloat)w/(GLfloat)h, // razão de aspecto
                 1.0, // plano de recorte próximo
                 10.0); // plano de recorte distante

  glMatrixMode(GL_MODELVIEW);
  glLoadIdentity();
  gluLookAt(0.0, 0.0, 1.0, // posição da câmera
            0.0, 0.0, 0.0, // centro do plano de projeção
            0.0, 1.0, 0.0); // vetor que indica a direção do topo da câmera
}

int carrega_malha()
{
  std::ifstream file("data/tweety.off");

  if (file.is_open()) {
    std::string type;
    int number_of_points, number_of_faces, dummy;
    file >> type;
    if (type.compare("OFF") != 0) {
      return 1; // não foi possível ler o conteúdo do arquivo
    }
    file >> number_of_points >> number_of_faces >> dummy;
    std::cerr << "número de pontos: " << number_of_points << std::endl;
    std::cerr << "número de faces: " << number_of_faces << std::endl;

    vertices.reserve(number_of_points);
    faces.reserve(number_of_faces);

    // leitura das coordenadas dos vértices
    for (int i = 0; i < number_of_points; ++i) {
      double x, y, z;
      file >> x >> y >> z;
      vertices.push_back( Vertex_3( Point_3(x,y,z) ) );
    }

    // leitura da conectividade das faces triangulares
    for (int i = 0; i < number_of_faces; ++i) {
      int k, v0, v1, v2;
      file >> k >> v0 >> v1 >> v2;
      faces.push_back( Face_3(v0, v1, v2) );
    }
    glutPostRedisplay();
    return 0; // OK
  }
  return 1; // não foi possível ler o conteúdo do arquivo
}

void teclado(unsigned char key, int x, int y)
{
  switch (key) {
    case 'c':
      if (carrega_malha() != 0) {
        std::cerr << "não foi possível ler a malha.\n";
      }
      break;

    case 27:
      exit(0);
      break;
  }
}

int main(int argc, char** argv)
{
  glutInit(&argc, argv);
  glutInitDisplayMode (GLUT_DOUBLE | GLUT_RGBA | GLUT_DEPTH);
  glutInitWindowSize (500, 500); 
  glutInitWindowPosition (100, 100);
  glutCreateWindow("SI041: Computação Gráfica - Aula 32");
  configure_iluminacao();
  glutDisplayFunc(desenha); 
  glutReshapeFunc(ajusta);
  glutKeyboardFunc(teclado);
  glutMainLoop();
  return 0;
}
